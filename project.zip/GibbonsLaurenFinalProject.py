from tkinter import *
from PIL import ImageTk, Image
import random
from random import randint

root = Tk()
root.title('World Flag Flashcards')
root.geometry("500x500")

# Create frames
flags_frame = Frame(root, width=500, height=500)

# Instructions labels
ins_label1 = Label(root, text="Identify the flag!", font=("Helvetica", 12))
ins_label1.pack(pady=7)
ins_label2 = Label(root, text="Click 'Answer' to submit your answer, then click 'Next'", font=("Helvetica", 10))
ins_label2.pack()


# Hide all previous frames
def hide_all_frames():
    for widget in flags_frame.winfo_children():
        widget.destroy()

    flags_frame.pack_forget()


correct_count = 0  # Counter for correct answers
incorrect_count = 0  # Counter for incorrect answers
# Create flag answers
def flag_answer():
    global correct_count
    global incorrect_count
    if flag_radio.get() == my_flag_answers[answer]:     # Check for correct answers
        response = "Correct!"
        correct_count += 1
    else:
        response = "Incorrect!"
        incorrect_count += 1

    answer_label.config(text=response)


# Results window function
def open_win():
    # Set up new window
    root.withdraw()
    top = Toplevel()
    top.title("Results")
    top.geometry("350x200")

    # Display results
    results_label = Label(top, text="Your score: \n" + str(correct_count) + " correct answer(s) \n" + str(incorrect_count) +
                                    " incorrect answer(s)", font=("Helvetica", 14))
    results_label.pack(pady=10)


# Initialize counter for number of flashcards answered
ans_counter = 0


# Create flags function
def flags():
    global ans_counter
    if ans_counter == 10:
        open_win()  # Open results window after 10 flashcards have been answered
    ans_counter += 1
    hide_all_frames()
    flags_frame.pack(fill=BOTH, expand=1)
    global show_flag
    show_flag = Label(flags_frame)
    show_flag.pack(pady=15)

    # Creat list of flags
    global my_flags
    my_flags = ['spain', 'greenland', 'thailand', 'newzealand', 'southafrica', 'costarica', 'qatar', 'sweden', 'turkey',
                'ukraine']
    # Create dictionary of answers
    global my_flag_answers
    my_flag_answers = {
        'spain': "spain",
        'greenland': "greenland",
        'thailand': "thailand",
        'newzealand': "new zealand",
        'southafrica': "south africa",
        'costarica': "costa rica",
        'qatar': "qatar",
        'sweden': "sweden",
        'turkey': "turkey",
        'ukraine': "ukraine"
    }

    # Create empty answer list and counter
    answer_list = []
    answer_count = 1
    global answer

    # Show flag image
    global flag_image
    answer = my_flags[ans_counter -2]      # Set answer to the index of the question number
    flag = "images/" + answer + ".png"
    flag_image = ImageTk.PhotoImage(Image.open(flag))
    show_flag.config(image=flag_image)      # Show flag image

    # Generate answer choices
    while answer_count < 5:
        rando = randint(0, len(my_flags) - 1)       # Randomize choices
        random.shuffle(my_flags)

        # Add first selection to a new list
        answer_list.append(my_flags[rando])

        # Remove from old list
        my_flags.remove(my_flags[rando])

        # Shuffle list
        random.shuffle(my_flags)

        # Increment answer count
        answer_count += 1

    # Add correct answer to list if not there already
    if answer not in answer_list:
        answer_list[3] = answer
    random.shuffle(answer_list)     # Shuffle answers


    # Create radio buttons
    global flag_radio
    flag_radio = StringVar()
    flag_radio.set(my_flag_answers[answer_list[0]])
    flag_radio.set(my_flag_answers[answer_list[0]])

    flag_radio_butto1 = Radiobutton(flags_frame, text=my_flag_answers[answer_list[0]].title(), variable=flag_radio,
                                    value=my_flag_answers[answer_list[0]]).pack()
    flag_radio_butto2 = Radiobutton(flags_frame, text=my_flag_answers[answer_list[1]].title(), variable=flag_radio,
                                    value=my_flag_answers[answer_list[1]]).pack()
    flag_radio_butto3 = Radiobutton(flags_frame, text=my_flag_answers[answer_list[2]].title(), variable=flag_radio,
                                    value=my_flag_answers[answer_list[2]]).pack()
    flag_radio_butto4 = Radiobutton(flags_frame, text=my_flag_answers[answer_list[3]].title(), variable=flag_radio,
                                    value=my_flag_answers[answer_list[3]]).pack()

    # Create an answer button
    flag_answer_button = Button(flags_frame, text="Answer", command=flag_answer)
    flag_answer_button.pack(pady=5)

    # Create a next button
    next_button = Button(flags_frame, text="Next", command=flags)
    next_button.pack(pady=5)

    # Create answer label
    global answer_label
    answer_label = Label(flags_frame, text="")
    answer_label.pack(pady=15)


# Call flags function
flags()

# Keep program running
root.mainloop()